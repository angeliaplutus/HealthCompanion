CREATE TABLE `project`.`account_dia` (
id int(11) NOT NULL AUTO_INCREMENT,
pregnancies int,
glucose int,
bloodpressure int,
skinthickness int,
insulin int,
bmi_dia float,
diabetes_pedigree_fnc float,
age_dia int,
outcome int,
PRIMARY KEY (id)
);
