CREATE TABLE `healthcomp`.`account_cardiovascular`( 
id int(11) NOT NULL AUTO_INCREMENT,
age1 int,
gender1 int,
height float,
weight float,
ap_hi int,
ap_lo int,
cholesterol int,
glu int,
smoke int,
alco int,
active int,
CARDIO_DISEASE int,
PRIMARY KEY (id)
);